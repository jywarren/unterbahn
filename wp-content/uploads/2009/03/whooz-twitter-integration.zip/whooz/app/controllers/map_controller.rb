class MapController < ApplicationController
  
  def index
    @tweet = Tweet.find(:all, :from=>"/statuses/friends_timeline/whooz.xml")
    render :xml => @tweet
  end
  
  def status_update
    Tweet.update_status(params[:status])
    @tweets = Tweet.find(:all, :from=>"/statuses/user_timeline/whooz.xml")
    render :xml => @tweets
  end

  def update_friend
    Tweet.direct_message('l20amesstCambri','This is only for you eyes')
    @tweets = Tweet.find(:all, :from=>"/statuses/friends_timeline/l20amesstCambri.xml")
    render :xml => @tweets
  end
  
end
