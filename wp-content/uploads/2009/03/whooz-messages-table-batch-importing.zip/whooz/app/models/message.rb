class Message < ActiveRecord::Base
end
